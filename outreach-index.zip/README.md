# OutReach - hub

This project is designed for businesses to manage their contacts, create message template and simulate target campaigns.

It provides admin portal to manage business workspace and workspace user.

It provides workspace users to manage contact with tagging, manage message template, manage and launch campaigns for selected tags of contacts and selecting templates and view campaign status

It contains authentication module, contacts module, home module, message template and campaign module


1. Authentication module
    * login and logout page for admin and user